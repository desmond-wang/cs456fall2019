Modification:
Removed the temple files of python from code folder, removed .DS_Store from Shared folder, remove shebang from the shell script.