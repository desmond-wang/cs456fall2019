#!/bin/bash
# Daiyang Wang (20646168)
# CS456 A3
# $1 is tracker ip address
# $2 is tracker port number
# $3 is peer min time to live
python3 ./code/peer.py $1 $2 $3

