#!/bin/bash
# Daiyang Wang (20646168)
# CS456 A3
python3 ./code/tracker.py

